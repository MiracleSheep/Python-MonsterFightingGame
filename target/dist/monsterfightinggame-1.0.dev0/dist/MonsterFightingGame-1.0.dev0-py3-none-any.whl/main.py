from startclass import start
from gameclass import Game


s = start()
g = Game()