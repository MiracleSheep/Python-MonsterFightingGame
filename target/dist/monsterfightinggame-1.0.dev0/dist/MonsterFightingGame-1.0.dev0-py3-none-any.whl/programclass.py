import time
class program:

    def talk(self,message,t):
        print(message)
        time.sleep(t)